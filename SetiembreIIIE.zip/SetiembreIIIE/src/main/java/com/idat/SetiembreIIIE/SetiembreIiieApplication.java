package com.idat.SetiembreIIIE;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SetiembreIiieApplication {

	public static void main(String[] args) {
		SpringApplication.run(SetiembreIiieApplication.class, args);
	}

}
