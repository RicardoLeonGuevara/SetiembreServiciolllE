package com.idat.SetiembreIIIE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SetiembreIiieApplicationTests {

	@Test
	void contextLoads() {
	}

}
